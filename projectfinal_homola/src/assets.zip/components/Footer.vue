<template>
    <footer class="footer">
      <span>&copy; 2025 ElectroShop. All rights reserved.</span>
    </footer>
  </template>
  
  <script>
  export default {
    name: 'Footer',
  };
  </script>
  
  <style>
  .footer {
    background: #007bff;
    color: white;
    text-align: center;
    padding: 10px;
    position: fixed;
    bottom: 0;
    width: 100%;
  }
  </style>
  