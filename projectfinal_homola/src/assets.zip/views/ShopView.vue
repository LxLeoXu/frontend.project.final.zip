<template>
    <div class="shop">
      <h1>Shop</h1>
      <div v-if="loading">Loading...</div>
      <div v-else>
        <div v-for="product in products" :key="product.id" class="product-card">
          <h2>{{ product.name }}</h2>
          <p>Price: {{ product.price }}€</p>
          <button @click="addToCart(product)">Add to Cart</button>
        </div>
        <h2 class="cart-title">
          <!-- SVG ikona -->
          <img src="@/components/icons/Shopping-Cart-Full--Streamline-Ultimate.svg" alt="Shopping Cart" class="cart-icon" />
          Shopping Cart
        </h2>
        <ul>
          <li v-for="(item, index) in cart" :key="index">
            {{ item.name }} - {{ item.price }}€
            <button @click="removeFromCart(index)">Remove</button>
          </li>
        </ul>
        <p>Total: {{ cartTotal }}€</p>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: "ShopView",
    data() {
      return {
        products: [],
        cart: [],
        loading: true,
      };
    },
    computed: {
      cartTotal() {
        return this.cart.reduce((total, item) => total + item.price, 0);
      },
    },
    methods: {
      async fetchProducts() {
        try {
          const response = await fetch('/data/products.json');
          this.products = await response.json();
        } catch (error) {
          console.error('Error loading products:', error);
        } finally {
          this.loading = false;
        }
      },
      addToCart(product) {
        this.cart.push(product);
      },
      removeFromCart(index) {
        this.cart.splice(index, 1);
      },
    },
    created() {
      this.fetchProducts();
    },
  };
  </script>
  
  <style scoped>
  .shop {
    padding: 20px;
  }
  
  .product-card {
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 16px;
    margin-bottom: 16px;
  }
  
  button {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 8px 16px;
    margin-top: 8px;
    border-radius: 4px;
    cursor: pointer;
  }
  
  button:hover {
    background-color: #0056b3;
  }
  
  ul {
    list-style: none;
    padding: 0;
  }
  
  ul li {
    margin-bottom: 10px;
  }
  
  .cart-title {
    display: flex;
    align-items: center;
    gap: 8px;
  }
  
  .cart-icon {
    width: 24px;
    height: 24px;
  }
  </style>
  